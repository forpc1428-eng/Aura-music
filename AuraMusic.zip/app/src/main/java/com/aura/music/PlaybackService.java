package com.aura.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/**
 * Keeps the app alive while music plays in the background and shows
 * a media notification with previous / play-pause / next controls.
 */
public class PlaybackService extends Service {

    static PlaybackService instance;
    private static final String CHANNEL = "aura_playback";
    private static final int NOTIF_ID = 7;

    private PowerManager.WakeLock wakeLock;
    private String title = "Aura";
    private String artist = "";
    private boolean playing = true;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Now playing", NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("Music playback controls");
        ch.setShowBadge(false);
        ch.setSound(null, null);
        nm.createNotificationChannel(ch);
        PowerManager pm = getSystemService(PowerManager.class);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Aura::Playback");
        wakeLock.setReferenceCounted(false);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (action != null) {
            switch (action) {
                case "PREV": MainActivity.command("prev"); break;
                case "TOGGLE": MainActivity.command("toggle"); break;
                case "NEXT": MainActivity.command("next"); break;
            }
            return START_NOT_STICKY;
        }
        if (intent != null) {
            title = orDefault(intent.getStringExtra("title"), "Aura");
            artist = orDefault(intent.getStringExtra("artist"), "");
            playing = intent.getBooleanExtra("playing", true);
        }
        Notification n = build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, n);
        }
        applyWakeLock();
        return START_NOT_STICKY;
    }

    /** Update the notification without restarting the service. */
    void update(String t, String a, boolean isPlaying) {
        title = orDefault(t, "Aura");
        artist = orDefault(a, "");
        playing = isPlaying;
        getSystemService(NotificationManager.class).notify(NOTIF_ID, build());
        applyWakeLock();
    }

    private void applyWakeLock() {
        try {
            if (playing) wakeLock.acquire(6 * 60 * 60 * 1000L);
            else if (wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) { }
    }

    private Notification build() {
        int imm = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        Intent open = new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 0, open, imm);

        Notification.Action prev = action(R.drawable.ic_prev, "Previous", "PREV", 1);
        Notification.Action toggle = action(playing ? R.drawable.ic_pause : R.drawable.ic_play,
                playing ? "Pause" : "Play", "TOGGLE", 2);
        Notification.Action next = action(R.drawable.ic_next, "Next", "NEXT", 3);

        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_note)
                .setContentTitle(title)
                .setContentText(artist)
                .setContentIntent(content)
                .setColor(Color.parseColor("#7C5CFF"))
                .setOngoing(playing)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setCategory(Notification.CATEGORY_TRANSPORT)
                .addAction(prev)
                .addAction(toggle)
                .addAction(next)
                .setStyle(new Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2))
                .build();
    }

    private Notification.Action action(int icon, String label, String act, int req) {
        Intent i = new Intent(this, PlaybackService.class).setAction(act);
        PendingIntent pi = PendingIntent.getService(this, req, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Action.Builder(Icon.createWithResource(this, icon), label, pi).build();
    }

    private static String orDefault(String s, String d) {
        return (s == null || s.isEmpty()) ? d : s;
    }

    @Override
    public void onDestroy() {
        instance = null;
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
