package com.aura.music;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.lang.ref.WeakReference;

public class MainActivity extends Activity {

    private static WeakReference<MainActivity> current = new WeakReference<>(null);
    private WebView web;

    /** Called by PlaybackService when a notification button is tapped. */
    static void command(final String cmd) {
        final MainActivity a = current.get();
        if (a == null || a.web == null) return;
        a.runOnUiThread(() -> a.web.evaluateJavascript(
                "window.auraCmd && window.auraCmd('" + cmd + "')", null));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        current = new WeakReference<>(this);

        // Edge-to-edge: draw behind the status bar for the glass look
        Window w = getWindow();
        w.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        w.setStatusBarColor(Color.TRANSPARENT);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#07070C"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        // Keep the audio engine at high priority even when the screen is off
        web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setTextZoom(100);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AuraNative");
        setContentView(web);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        float density = getResources().getDisplayMetrics().density;
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        float sb = id > 0 ? getResources().getDimensionPixelSize(id) / density : 24f;

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/www/index.html?sb=" + sb);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    // NOTE: we deliberately do NOT call web.onPause()/pauseTimers() so music keeps playing in background.

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("window.auraBack ? window.auraBack() : false", value -> {
            if (!"true".equals(value)) moveTaskToBack(true);
        });
    }

    @Override
    protected void onDestroy() {
        if (isFinishing()) stopService(new Intent(this, PlaybackService.class));
        if (web != null) {
            web.removeJavascriptInterface("AuraNative");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    /** JavaScript → Android bridge. */
    class Bridge {
        @JavascriptInterface
        public void playing(final boolean isPlaying, final String title, final String artist) {
            runOnUiThread(() -> {
                PlaybackService svc = PlaybackService.instance;
                if (svc != null) {
                    svc.update(title, artist, isPlaying);
                } else if (isPlaying) {
                    Intent i = new Intent(MainActivity.this, PlaybackService.class);
                    i.putExtra("title", title);
                    i.putExtra("artist", artist);
                    i.putExtra("playing", true);
                    try { startForegroundService(i); } catch (Exception ignored) { }
                }
            });
        }

        @JavascriptInterface
        public void haptic() {
            try {
                Vibrator v = getSystemService(Vibrator.class);
                if (v != null && v.hasVibrator()) {
                    v.vibrate(VibrationEffect.createOneShot(8, 60));
                }
            } catch (Exception ignored) { }
        }
    }
}
