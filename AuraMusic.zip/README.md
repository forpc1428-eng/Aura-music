# Aura — liquid-glass music player

Free, legal music streaming app powered by the Audius open music network.

## Get the APK (free, no PC needed)

1. Create a free account at github.com and make a **new repository** (e.g. `aura-music`).
2. Upload **all files and folders from this zip** (keep the folder structure, including `.github`).
   - Easiest on a PC: drag the unzipped folder contents onto the repo's "Add file → Upload files" page.
3. Open the **Actions** tab → "Build Aura APK" → it runs automatically (or press **Run workflow**).
4. After ~4–6 minutes, open the finished run → download **Aura-Music-APK** → unzip → install `Aura-Music.apk`.
   (Android will ask you to allow "Install unknown apps" once.)

## Build locally (optional)
Open the folder in Android Studio → Build → Build APK(s).

## Features
- Liquid-glass UI, animated aurora background that recolours to each song's artwork
- Trending (week / month / all-time), 14 genre filters, top playlists, instant search
- Full-screen player: drag down to close, swipe artwork for next/previous, gyroscope 3D tilt
- Shuffle, repeat (all / one), queue, play next, sleep timer (with fade-out), likes, recently played
- Background playback with notification controls, lock-screen controls, haptics
- Offline-cached lists so the home screen loads instantly

## Editing the app
All the UI lives in `app/src/main/assets/www/index.html` — open it in any browser to preview.

## Before publishing on Play Store
- Replace the debug signing in `app/build.gradle` with your own keystore.
- Follow Audius API terms and credit artists. Music comes from Audius; only stream tracks the API marks as streamable.
